const KEY_CODES = {
    UP: 38,
    DOWN: 40,
    ENTER: 13,
    ZERO: 48,
    NINE: 57,
    DELETE: 8,
    LEFT: 37,
    R: 82,
    C: 67
};
